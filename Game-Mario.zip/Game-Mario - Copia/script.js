const mario = document.querySelector('.mario');
const tubo = document.querySelector('.tubo');


const jump = () =>{
    //add classe jump ao mario 
    mario.classList.add('jump');

    setTimeout(()=>{
        mario.classList.remove('jump'); //remove classe para que seja possivel pular novamente
    },500)
} 

const loop = setInterval(()=>{

    const posicaotubo = tubo.offsetLeft;//verfica posicao a esquerda do tubo;
    const posicaomario = +window.getComputedStyle(mario).bottom.replace(`px`, ``);//capta altura do pulo do personagem
                          //+ tenta converter string para numero                                                     //replace retira propriedade px do pulo, pois window retorna string

    if (posicaotubo <= 141 && posicaotubo >0 && posicaomario < 120){

        tubo.style.animation = 'none';
        tubo.style.left = `${posicaotubo}px`;//para tubo ao ser tocado;
   

        mario.style.animation = 'none';
        mario.style.bottom = `${posicaomario}px`;//Para personagem em cima do tubo caso seja tocado;

        mario.src='./imagens/gameover.png'//altera imagem do personagem ao perder
        mario.style.width = '140px'//dimensao da img de game over
        mario.style.marginLeft = '40px'

        clearInterval(loop);
    }

}, 10);


document.addEventListener('keydown', jump);


